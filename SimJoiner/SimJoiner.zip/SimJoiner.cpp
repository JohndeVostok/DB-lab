#include "SimJoiner.h"
#include "SimSearcher.h"
#include <fstream>
#include <sstream>
#include <cstdio>

using namespace std;

SimJoiner::SimJoiner() {
}

SimJoiner::~SimJoiner() {
}

int loadData(vector <string> &res, const string &filename) {
	res.clear();
	ifstream fin(filename.c_str());
	char buf[2050];
	while (fin.getline(buf, 2048)) res.emplace_back(buf);
	return SUCCESS;
}

int SimJoiner::joinJaccard(const char *filename1, const char *filename2, double threshold, vector<JaccardJoinResult> &result) {
    result.clear();
    return SUCCESS;
}

int SimJoiner::joinED(const char *filename1, const char *filename2, unsigned threshold, vector<EDJoinResult> &result) {
    result.clear();
    vector <string> data;
    loadData(data, filename1);
    SimSearcher searcher;
    searcher.createIndex(filename2, 3);
    vector <pair <unsigned, unsigned>> tmp;
    for (int i = 0; i < data.size(); i++) {
    	tmp.clear();
		searcher.searchED(data[i].c_str(), threshold, tmp);
		for (const auto &res : tmp) {
			result.emplace_back(i, res.first, res.second);
		}
    }
    return SUCCESS;
}
